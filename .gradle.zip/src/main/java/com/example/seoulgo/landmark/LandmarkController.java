package com.example.seoulgo.landmark;

import com.example.seoulgo.common.ApiResponse;
import com.example.seoulgo.landmark.LandmarkDtos.NearbyRes;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/landmarks")
@RequiredArgsConstructor
public class LandmarkController {

    private final LandmarkService landmarkService;

    // 서울 시청 좌표가 기본값. 위치 권한을 거부한 사용자도 지도를 볼 수 있음
    @GetMapping("/nearby")
    public ApiResponse<NearbyRes> nearby(
            @AuthenticationPrincipal Long userId,
            @RequestParam(defaultValue = "37.5665") double lat,
            @RequestParam(defaultValue = "126.9780") double lng,
            @RequestParam(defaultValue = "50000") int radius) {
        return ApiResponse.ok(landmarkService.nearby(userId, lat, lng, radius));
    }
}
